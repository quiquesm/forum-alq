package com.post;

public enum Category {

	question, suggestion, clarification
	
}
