package com.thread;

import java.util.List;

public interface ThreadService {
	
	public List<Thread> getThread();

}
